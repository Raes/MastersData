This version has been updated to the synset offsets used in WordNet 3.0

The WNCoords.dat file is now replaced by mapping.dat, which has a new format:
synset offset, geonames id, lat and lon, separated by tabulations.

The mapping.txt file contains a human-readable description of the mappings.

The not_mapped.txt file contains the synset which have been removed from the mappings because they were not correct and it was not possible to establish a geonames matching.
